// diary.js  (run: npm install express body-parser && node diary.js)
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

let notes = []; // { id, title, content, coverPhotoBase64 }

app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Diary</title>
  <style>
    body { font-family: Arial, sans-serif; background:#f2f4f8; margin:0; padding:0; }
    .container { max-width: 800px; margin: 20px auto; background:#fff; padding:20px;
                 border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
    h1 { margin-top:0; }
    label { display:block; margin-top:10px; font-weight:bold; }
    input[type="text"], textarea { width:100%; padding:6px; margin-top:4px; }
    textarea { resize:vertical; }
    button { margin-top:10px; padding:8px 14px; cursor:pointer; }
    .preview img { max-width:200px; margin-top:10px; border-radius:4px; }
    .note { border:1px solid #ddd; padding:10px; margin-top:10px; border-radius:4px; }
    .note img { max-width:120px; display:block; margin-bottom:6px; border-radius:4px; }
  </style>
</head>
<body>
<div class="container">
  <h1>My Diary</h1>

  <div>
    <label>Title</label>
    <input id="title" type="text" placeholder="Diary title" />

    <label>Content</label>
    <textarea id="content" rows="5" placeholder="Write your note..."></textarea>

    <label>Cover photo</label>
    <input id="cover" type="file" accept="image/*" />

    <div id="coverPreview" class="preview"></div>

    <button id="saveBtn">Save Entry</button>
  </div>

  <hr />

  <h2>Previous Entries</h2>
  <div id="notesList"></div>
</div>

<script>
  const coverInput = document.getElementById('cover');
  const coverPreview = document.getElementById('coverPreview');
  const saveBtn = document.getElementById('saveBtn');
  const notesList = document.getElementById('notesList');

  let coverPhotoBase64 = null;

  coverInput.addEventListener('change', function (e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      coverPhotoBase64 = reader.result;
      coverPreview.innerHTML = '<img src="' + coverPhotoBase64 + '" />';
    };
    reader.readAsDataURL(file);
  });

  async function loadNotes() {
    const res = await fetch('/api/notes');
    const data = await res.json();
    notesList.innerHTML = '';
    data.forEach(n => {
      const div = document.createElement('div');
      div.className = 'note';
      div.innerHTML =
        (n.coverPhotoBase64 ? '<img src="' + n.coverPhotoBase64 + '"/>' : '') +
        '<h3>' + n.title + '</h3>' +
        '<p>' + n.content + '</p>';
      notesList.appendChild(div);
    });
  }

  saveBtn.addEventListener('click', async function () {
    const title = document.getElementById('title').value.trim();
    const content = document.getElementById('content').value.trim();
    if (!title || !content) {
      alert('Title and content are required');
      return;
    }
    await fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, content, coverPhotoBase64 })
    });
    document.getElementById('title').value = '';
    document.getElementById('content').value = '';
    coverInput.value = '';
    coverPhotoBase64 = null;
    coverPreview.innerHTML = '';
    loadNotes();
  });

  loadNotes();
</script>
</body>
</html>`);
});

app.get('/api/notes', (req, res) => {
  res.json(notes);
});

app.post('/api/notes', (req, res) => {
  const { title, content, coverPhotoBase64 } = req.body;
  const note = { id: Date.now(), title, content, coverPhotoBase64 };
  notes.push(note);
  res.status(201).json(note);
});

app.listen(3000, () => {
  console.log('Diary running at http://localhost:3000');
});
