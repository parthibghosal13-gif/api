// server.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// allow Angular/other origins
app.use(cors());

// parse JSON body
app.use(bodyParser.json());

// serve static files from /public
app.use(express.static(path.join(__dirname, 'public')));

// in-memory store
let notes = []; // {id, title, content, coverPhotoBase64}

// API: get all notes
app.get('/api/notes', (req, res) => {
  res.json(notes);
});

// API: create note
app.post('/api/notes', (req, res) => {
  const { title, content, coverPhotoBase64 } = req.body;
  const note = { id: Date.now(), title, content, coverPhotoBase64 };
  notes.push(note);
  res.status(201).json(note);
});

// serve HTML diary at root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'diary.html'));
});

app.listen(3000, () => {
  console.log('Diary API + HTML on http://localhost:3000');
});
